package com.example.kuisioner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;



public class MainActivity extends AppCompatActivity {
    @BindView(R.id.edUser)
    EditText edUser;
    @BindView(R.id.edPw)
    EditText edPw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

    }
    @OnClick(R.id.btnLogin)
    void btnLogin(){
        String strUser, strPw;
        strUser = edUser.getText().toString();
        strPw = edPw.getText().toString();

        if (strUser.equals("admin") && strPw.equals("123")) {
            Intent a = new Intent(MainActivity.this, Main2Activity.class);
            a.putExtra("username" , strUser);
            a.putExtra("pw", strPw);
            startActivity(a);
            finish();
        } else {
            Toast.makeText(getApplicationContext(),"Maaf inputan salah", Toast.LENGTH_LONG).show();

        }
    }
}
